export const lastTextOfUrl =
  window.location.href.split("/")[window.location.href.split("/").length - 1];
