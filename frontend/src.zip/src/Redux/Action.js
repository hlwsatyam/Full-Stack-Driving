export const PerfListAction = (input) => {
  return {
    type: "PerfListAction",
    text: input,
  };
};
