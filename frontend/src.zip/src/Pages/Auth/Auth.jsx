import React from "react";
import Form from "./Form/Form";

function Auth() {
  return (
    <div className="bg-slate-600 h-screen ">
      <Form />
    </div>
  );
}

export default Auth;
